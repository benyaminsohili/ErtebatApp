package com.ertebat.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

private const val SITE_URL = "https://o.hsushxh.dpdns.org/"

class MainActivity : ComponentActivity() {
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingWebResources: Array<String> = emptyArray()

    private val mediaPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val request = pendingWebPermission
            val required = pendingWebResources
            val cameraNeeded = PermissionRequest.RESOURCE_VIDEO_CAPTURE in required
            val micNeeded = PermissionRequest.RESOURCE_AUDIO_CAPTURE in required
            val cameraGranted = !cameraNeeded || result[Manifest.permission.CAMERA] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            val micGranted = !micNeeded || result[Manifest.permission.RECORD_AUDIO] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (request != null && cameraGranted && micGranted) request.grant(required)
            else request?.deny()
            pendingWebPermission = null
            pendingWebResources = emptyArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val prefs = remember { getSharedPreferences("ertebat_settings", MODE_PRIVATE) }
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            var notifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }
            var privacyMode by remember { mutableStateOf(prefs.getBoolean("privacy", true)) }
            var fontScale by remember { mutableFloatStateOf(prefs.getFloat("font_scale", 1f)) }
            var page by remember { mutableStateOf("home") }

            SideEffect {
                if (privacyMode) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }

            ErtebatTheme(dark) {
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = page == "home",
                                onClick = { page = "home" },
                                icon = { Text("⌂") },
                                label = { Text("ارتباط") }
                            )
                            NavigationBarItem(
                                selected = page == "settings",
                                onClick = { page = "settings" },
                                icon = { Text("⚙") },
                                label = { Text("تنظیمات") }
                            )
                        }
                    }
                ) { padding ->
                    if (page == "home") {
                        SiteScreen(
                            modifier = Modifier.padding(padding),
                            fontScale = fontScale,
                            onMediaPermission = { request ->
                                // Only allow media capture requests from the trusted site origin.
                                if (request.origin.scheme != "https" || request.origin.host != "o.hsushxh.dpdns.org") {
                                    request.deny()
                                } else {
                                    val allowedResources = request.resources.filter {
                                        it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                                    }.toTypedArray()
                                    if (allowedResources.isEmpty()) {
                                        request.deny()
                                        return@SiteScreen
                                    }
                                    pendingWebPermission = request
                                    pendingWebResources = allowedResources
                                    val androidPermissions = buildList {
                                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in allowedResources) add(Manifest.permission.CAMERA)
                                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in allowedResources) add(Manifest.permission.RECORD_AUDIO)
                                    }.distinct()
                                    val missing = androidPermissions.filter {
                                        ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                                    }
                                    if (missing.isEmpty()) {
                                        request.grant(allowedResources)
                                        pendingWebPermission = null
                                        pendingWebResources = emptyArray()
                                    } else {
                                        mediaPermissionLauncher.launch(missing.toTypedArray())
                                    }
                                }
                            }
                        )
                    } else {
                        SettingsScreen(
                            modifier = Modifier.padding(padding),
                            dark = dark,
                            onDarkChange = {
                                dark = it
                                prefs.edit().putBoolean("dark", it).apply()
                            },
                            notifications = notifications,
                            onNotificationsChange = {
                                notifications = it
                                prefs.edit().putBoolean("notifications", it).apply()
                            },
                            privacyMode = privacyMode,
                            onPrivacyChange = {
                                privacyMode = it
                                prefs.edit().putBoolean("privacy", it).apply()
                            },
                            fontScale = fontScale,
                            onFontScaleChange = {
                                fontScale = it
                                prefs.edit().putFloat("font_scale", it).apply()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ErtebatTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF55B8FF),
        secondary = Color(0xFF8A7CFF),
        background = Color(0xFF090F1C),
        surface = Color(0xFF111B2B)
    ) else lightColorScheme(
        primary = Color(0xFF087CC1),
        secondary = Color(0xFF6554C0)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun SiteScreen(
    modifier: Modifier,
    fontScale: Float,
    onMediaPermission: (PermissionRequest) -> Unit
) {
    var loading by remember { mutableStateOf(true) }
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.brand_emblem),
                contentDescription = "لوگوی سامانه ارتباط",
                modifier = Modifier.size(54.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text("سامانه ارتباط", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("تماس صوتی و تصویری", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.weight(1f))
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.textZoom = (fontScale * 100).toInt()
                    settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val host = request.url.host.orEmpty()
                            return !(host == "o.hsushxh.dpdns.org" || host.endsWith(".dpdns.org"))
                        }
                        override fun onPageFinished(view: WebView, url: String) { loading = false }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onPermissionRequest(request: PermissionRequest) {
                            val wantsMedia = request.resources.any {
                                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                                    it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                            }
                            if (wantsMedia) onMediaPermission(request) else request.deny()
                        }
                    }
                    loadUrl(SITE_URL)
                }
            },
            update = { webView ->
                webView.settings.textZoom = (fontScale * 100).toInt()
            }
        )
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    dark: Boolean,
    onDarkChange: (Boolean) -> Unit,
    notifications: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    privacyMode: Boolean,
    onPrivacyChange: (Boolean) -> Unit,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit
) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("تنظیمات پیشرفته", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("شخصی‌سازی تجربه ارتباط", color = MaterialTheme.colorScheme.onSurfaceVariant)
        SettingSwitch("تم تاریک", "ظاهر برنامه را تاریک یا روشن کن", dark, onDarkChange)
        SettingSwitch("ترجیح اعلان‌ها", "ذخیره انتخاب شما؛ اعلان پوش به سرویس سمت سرور نیاز دارد", notifications, onNotificationsChange)
        SettingSwitch("حریم خصوصی", "جلوگیری از اسکرین‌شات و ضبط صفحه برنامه", privacyMode, onPrivacyChange)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("اندازه نوشته‌ها", fontWeight = FontWeight.SemiBold)
                Text("${(fontScale * 100).toInt()}٪", color = MaterialTheme.colorScheme.primary)
                Slider(value = fontScale, onValueChange = onFontScaleChange, valueRange = 0.85f..1.25f)
                Text("اندازه نوشته‌های صفحه سایت نیز با این گزینه تغییر می‌کند.", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("درباره برنامه", fontWeight = FontWeight.Bold)
                Text("سامانه ارتباط • نسخه 1.0.0")
                Text("ساخته‌شده با Kotlin و Jetpack Compose", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            "توجه: اعلان پوش نوتیفیکیشن و تنظیمات واقعی سمت سرور به API یا سرویس اعلان سایت نیاز دارد.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}
